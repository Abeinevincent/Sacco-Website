  <!------ HEADER FILE ------->
  <?php include "header.php";?>

  <!-- news and updates top image section -->
  <section id="newsi">
      <img src="image/cent.jpg" class="w-100 adj-margin" alt="About Us Image" />
  </section>

  <div class="container w-60 my-3">
    <div class="row">
      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>

      <div class="col-md-4 justify-content-center">
        <div class="card bg-light mb-3">
          <div class="card-header text-white bg-secondary">News Header</div>
          <div class="card-body">
            <h5 class="card-title">Light card title</h5>
            <p class="card-text">
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repudiandae et corrupti debitis. Quis veniam velit quia.
            </p> 
            <div class="text-muted">Posted: December 16, 2020</div>
            <button type="button" class="btn btn-primary">Read More</button>
          </div> 
        </div>
      </div>
    </div>
  </div>


  <!------ FOOTER SECTION ------>
  <?php include "footer.php";?>
