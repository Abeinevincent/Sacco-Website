// Cool counter
$(document).ready(function() {
	$('.counter').each(function () {
		$(this).prop('Counter',0).animate({
			Counter: $(this).text() }, {
			duration: 4000,
			easing: 'swing',
			step: function (now){
			$(this).text(Math.ceil(now));
		}
});
});

// Toggle the hidden divs for signin and search by clicking on their btns
// var hiddenBox = $( "#show_signin" );
// $( "#search-input .search" ).on( "click", function( event ) {
//   hiddenBox.show();
// });


// Toggle the active class with the clicked element in the navbar


// Activate slide to top button
// $(document).ready(function(){
// 	if(this.scrollY > 500){
// 		$('.scroll-up-btn').addClass("show")
// 	}else{
// 		$('scroll-up-btn').removeClass('show')
// 	}

// 	$('scroll-up-btn').click(function(){
// 		$('html').animate({scrollTop: 0});
// 		// Remove the smooth scroll behaviour on scroll
// 		$('html').css("scroll-behaviour", "auto");
// 	});
// });