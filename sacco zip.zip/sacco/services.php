    <!------ HEADER FILE ------->
  <?php include "header.php";?>
  
  <!------------------ OTHER SERVICES MAIN SECTION ------------------->  

  <!-- others top image section -->
  <section id="contacti">
      <img src="image/cent.jpg" class="w-100 adj-margin" alt="About Us Image" />
  </section>

  <!-- Other Services Section -->

  
    

     
  <!------ FOOTER SECTION ------>
  <?php include "footer.php";?>