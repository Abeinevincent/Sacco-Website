  <!------ HEADER FILE ------->
  <?php include "header.php";?>

  <!------------------ LOANS MAIN SECTION ------------------->
  <!-- Loans top image section -->
  <section>
      <img src="image/loan.jpg" class="d-block w-100 img-responsive" alt="About Us Image"/>
  </section>


  <!-- loans section  -->
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="loans-list-page">
          <div class="row">

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

            <div class="col-sm-6 col-md-4 ">
              <div class="card">
                <div class="card-body text-center">
                  <img src="image/icon.jpg" width="64px" alt="Directions" title="Get Directions" class="direction img-circle" />
                  <h4>Cente Salary Loan</h4>
                  <p>
                    Let your big plans and dreams come to life with the CenteSalary loan. Get fast loans with flexibl<br/> 
                  </p>
                  <p><a class="btn btn-sm btn-danger" href="#">Read More</a></p>
                </div>
              </div>
            </div>

          </div>
        <div class="row"></div>
      </div>
    </div>
  </div>
  </div>
  
  <!------ FOOTER SECTION ------>
  <?php include "footer.php";?>


