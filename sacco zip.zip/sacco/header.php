<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <!-- Important meta tags -->
  <meta charset="utf-8" />
  <meta name="description" content="Sacco X Website built by sofcodesTech" />
  <meta name="kewords" content="Awesome Website, Sacco X, About Sacco X, Sacco X Home, Contact Sacco X" />
  
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  
  <!-- Font awesome -->
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />

  <!-- AOS CSS -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" type="text/css" />
  
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="style.css"  />

  <!-- Website title -->
  <title>
    Sacco X
  </title>
</head>

<!----------------------- Document Body ------------------------->
<body>
  <!------------------- Top navigation bar --------------->
  <div class="show-signin w-100" id="show_signin" style="height: 60px; background-color: green; display: none;">
    Toggle Test
  </div>

  <section id="top_nav" class="sticky-top">
    <div class="top-nav">

      <!-- Logo img -->
      <a href="#" class="ml-4 mt-2">
        <img class="mt-3" src="image/amfiu-logo.png">
      </a>

      <!-- Top contact section -->
      <a href="tel:+266589375456" class="text-white text-center mt-5 phone-no" style="margin-left: 20%">
        <i class="fa fa-phone"></i>
        <span class="contact-us mr-3">+256708364936</span>
      </a>
      <a href="mailto:info@saccox.ac.ug" class="text-white text-center email-id">
        <i class="fa fa-envelope"></i>
        <span class="email-us">info@saccox.ac.ug</span>
      </a>

        <!-- Top login section -->
        <a href="#show_signin" class="float-right signin bg-warning text-white mt-0 ml-2 p-1" style="margin-right: 30px;" title="Login">
          <i class="icon1 top-icons fa fa-lock"></i>
          <span class="text1">Login</span> 
          <span class="text2">Close</span>
        </a>

        <!-- <a href="#" class="float-right signup bg-danger text-white mt-0 ml-2 p-1" title="Sign Up">
          <i class="icon2 top-icons fa fa-user"></i> 
          <span class="text1">Sign-Up</span> 
          <span class="text2">Close</span>
        </a> -->

        <a href="#" id="search-input" class="float-right search bg-success text-white mt-0 ml-2 p-1" title="Search Here..">
          <i class="icon3 top-icons fa fa-search"></i> 
          <span class="text1">Search here..</span> 
          <span class="text2">Close</span>
        </a>
    </div>
  
    <!---------------- Important notice section ------------->
    <section id="info_notice">
      <div class="text-white wrap-word text-center">
          Happy new year to all Sacco X council, staff and members... Let's remember to Stay Safe... Sanitize and Wear your Mask
      </div>
    </section>

    <!----------------- Main navigation bar ---------------->
    <nav class="navbar navbar-expand-lg">
        <a href="#" class="navbar-brand"></a>
        <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler collapsed">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <!-- Active class -->
            <li class="nav-item">
              <a href="home.php" class="nav-link active text-white px-3" style="background-color: blue!important; height: 48px!important;">
                <i class="fa fa-home text-white"></i>
              </a>
            </li>
            <li class="nav-item"><a class="nav-link link1" href="about.php">About Us</a></li>
            <li class="nav-item"><a class="nav-link link1" href="news.php">News & Updates</a></li>
            <li class="nav-item"><a class="nav-link link1" href="gallery.php">Gallery</a></li>
            <li class="nav-item"><a class="nav-link link1" href="member.php">Membership</a></li>
            <li class="nav-item"><a class="nav-link link1" href="loans.php">Loan Products</a></li>
            <li class="nav-item"><a class="nav-link link1" href="branches.php">Branches & Outreach</a></li>
            <li class="nav-item"><a class="nav-link link1" href="mbanking.php">Mobile Banking</a></li>
            <li class="nav-item"><a class="nav-link link1" href="careers.php">Careers</a></li>
            <li class="nav-item"><a class="nav-link link1" href="contact.php">Contact Us</a></li>
            <li class="nav-item"><a class="nav-link link1" href="services.php">Other Services</a></li>
          </ul>
        </div> 
    </nav>
  </section>



