  <!------ HEADER FILE ------->
  <?php include "header.php";?>

      <!-- About top image section -->
      <section id="formsti">
          <img src="image/cent.jpg" class="w-100 adj-margin" alt="About Us Image" />
      </section>

      <!-- Main heading -->
      <div class="container w-60 add-border py-3 my-3">
        <div class="board">
          <h4 class="title text-primary">DOWNLOAD FORMS HERE</h4>
          <p class="text"></p>
        </div>
      </div>


      <!-- Division with major membership content -->
      <div class="container w-60 add-border my-3">
        <div class="individual-member">
          <h4 class="title text-primary">Individual Membership Forms</h4>
       
            <div class="w-100 bg-success text-white"><a href="#" class="text-white text-decoration-none style-links">Click here to download forms</a></div>
            <div class="description">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Velit dolorum nobis 
                quasi at alias ipsa commodi obcaecati, sapiente molestiae beatae 
                deserunt quos itaque deleniti placeat consequuntur eaque dignissimos suscipit rem!
            </div>
        </div>
               
      </div>
      <div class="container w-60 add-border my-3">
        <div class="individual-member">
          <h4 class="title text-primary">Group Membership Forms</h4>
       
            <div class="w-100 bg-success text-white"><a href="#" class="text-white text-decoration-none style-links">Click here to download forms</a></div>
            <div class="description">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Velit dolorum nobis 
                quasi at alias ipsa commodi obcaecati, sapiente molestiae beatae 
                deserunt quos itaque deleniti placeat consequuntur eaque dignissimos suscipit rem!
            </div>
        </div>
               
      </div>
      <div class="container w-60 add-border my-3">
        <div class="individual-member">
          <h4 class="title text-primary">Company Membership Forms</h4>
       
            <div class="w-100 bg-success text-white"><a href="#" class="text-white text-decoration-none style-links">Click here to download forms</a></div>
            <div class="description">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Velit dolorum nobis 
                quasi at alias ipsa commodi obcaecati, sapiente molestiae beatae 
                deserunt quos itaque deleniti placeat consequuntur eaque dignissimos suscipit rem!
            </div>
        </div>
               
      </div>

    <!------ FOOTER SECTION ------>
    <?php include "footer.php";?>
