  <!------ HEADER FILE ------->
  <?php include "header.php";?>
  

  <!------------------ CAREERS' MAIN SECTION ------------------->

  <!-- Mobile banking top image section -->
  <section>
      <img src="image/careers.jpg" class="d-block w-100 img-responsive" alt="About Us Image"/>
  </section>

  <!-- careers section -->
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <h1>Working at Centenary</h1>
            <p>
              Welcome to Centenary Bank&rsquo;s careers section. We are Uganda's leading commercial microfinance Bank, employing more than 2,700 staff. Joining Centenary Bank is an opportunity to be part of a dynamic team working to offer appropriate financial solutions to over 1.7 million customers countrywide.
            </p>
            <p>See Bottom Of the page</p>
            <h3>To apply:</h3>
            <p>
              <a href="../../../downloads/Application_for_Employment_Form-2018.pdf" target="_blank" rel="noopener">Download an application</a> for employment form <a href="../../../downloads/Application_for_Employment_Form-2018.pdf" target="_blank" rel="noopener">Here</a><br />b. Fill the form and enclose an application letter, updated Curriculum Vitae (CV), plus copies of all academic credentials, testimonials and contact details of three competent referees. <br />c. Submit your application to:
            </p>
            <p>
              General Manager Human Resources<br />Centenary Bank<br />P.O. Box 1892<br />Kampala
            </p>
            <p>
              Note; We appreciate the interest you have shown in growing the Bank business with our team. However only shortlisted candidates will be contacted. Please Consider your application unsuccessful if we have not contacted you two weeks from the closing date of this advertisement.
            </p>

            <table class="table table-hover">
              <thead class="thead-light">
                <tr>
                  <th>REF NO</th>
                  <th>JOB TITLE</th>
                  <th>CLOSING DATE</th>
                </tr>
              </thead>
            <tbody>

          <!-- php code to get careers from database here -->

            </tbody>
          </table>

        </div>
      </div>
    </div>
  </div>
</div>

  <!------ FOOTER SECTION ------>
  <?php include "footer.php";?>

  
