  <!------ HEADER FILE ------->
  <?php include "header.php";?>
  
  <!------------------ BRANCHES' MAIN SECTION ------------------->
  <!-- branches top image section -->
  <section>
    <img src="image/cent.jpg" class="d-block w-100 img-responsive" alt="About Us Image"/>
  </section>

  <!--BRANCHES TABLE SECTION-->
  <div class="container branch">
    <div class="row">
      <div class="col-md-12">
        <table class="table table-bordered table-hover">
          <thead class="thead-dark">
            <tr>
              <th>LOCATION</th>
              <th>ADDRESS</th>
              <th>OPENING HOURS</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row">Mbarara</th>
              <td>Plot II, Block D, Bundibibugyo Town council Fort Portal Road Highway Tel: +256 414 698 460 +256 414 698 46</td>
              <td>Mon - Fri 8:30am to 5:00pm Sat 8:30am to 1:30pm</td>
            </tr>
            <tr>
              <th scope="row">Mbarara</th>
              <td>Plot II, Block D, Bundibibugyo Town council Fort Portal Road Highway Tel: +256 414 698 460 +256 414 698 46</td>
              <td>Mon - Fri 8:30am to 5:00pm Sat 8:30am to 1:30pm</td>
            </tr>
            <tr>
              <th scope="row">Mbarara</th>
              <td>Plot II, Block D, Bundibibugyo Town council Fort Portal Road Highway Tel: +256 414 698 460 +256 414 698 46</td>
              <td>Mon - Fri 8:30am to 5:00pm Sat 8:30am to 1:30pm</td>
            </tr>
                <tr>
              <th scope="row">Mbarara</th>
              <td>Plot II, Block D, Bundibibugyo Town council Fort Portal Road Highway Tel: +256 414 698 460 +256 414 698 46</td>
              <td>Mon - Fri 8:30am to 5:00pm Sat 8:30am to 1:30pm</td>
            </tr>
            <tr>
              <th scope="row">Mbarara</th>
              <td>Plot II, Block D, Bundibibugyo Town council Fort Portal Road Highway Tel: +256 414 698 460 +256 414 698 46</td>
              <td>Mon - Fri 8:30am to 5:00pm Sat 8:30am to 1:30pm</td>
            </tr>
            <tr>
              <th scope="row">Mbarara</th>
              <td>Plot II, Block D, Bundibibugyo Town council Fort Portal Road Highway Tel: +256 414 698 460 +256 414 698 46</td>
              <td>Mon - Fri 8:30am to 5:00pm Sat 8:30am to 1:30pm</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- End of branches -->
   
  <!------ FOOTER SECTION ------>
  <?php include "footer.php";?>
